from django.apps import AppConfig


class JuheappConfig(AppConfig):
    name = 'juheapp'
